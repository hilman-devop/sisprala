// server.js — bootstrap Express + middleware keamanan
import express from 'express';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { attachAuth } from './src/auth.js';
import { registerRoutes } from './src/routes.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
export const app = express();
export default app; // Vercel: entrypoint function wajib punya default export

app.disable('x-powered-by');
// Di shared hosting (LiteSpeed/Passenger) aplikasi berada di belakang reverse proxy
app.set('trust proxy', 1);
app.use(express.urlencoded({ extended: false, limit: '2mb' }));
app.use(express.json({ limit: '2mb' }));

// ── Security headers ──
app.use((req, res, next) => {
  res.setHeader('Content-Security-Policy',
    "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; " +
    "object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'");
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=(), payment=(), usb=()');
  res.setHeader('Strict-Transport-Security', 'max-age=63072000; includeSubDomains');
  next();
});

app.use(attachAuth);
app.use('/img', express.static(join(__dirname, 'public/img'), { maxAge: '1h' }));
app.use('/css', express.static(join(__dirname, 'public/css')));
app.use('/js', express.static(join(__dirname, 'public/js')));
app.use('/uploads', express.static(join(__dirname, 'public/uploads')));
app.use('/favicon.ico', express.static(join(__dirname, 'public/favicon.ico')));

registerRoutes(app);

app.use((req, res) => res.status(404).send('404 — Halaman tidak ditemukan'));

const PORT = process.env.PORT || 3000;
// Passenger/CloudLinux (DirectAdmin) memuat file ini sebagai entrypoint, jadi default-nya listen.
// Vercel meng-import app dari api/index.js → jangan listen di sana. Test set NO_LISTEN=1.
if (!process.env.NO_LISTEN && !process.env.VERCEL) {
  app.listen(PORT, () => console.log(`SISPRALA jalan di ${String(PORT).startsWith('/') ? 'socket ' + PORT : 'http://localhost:' + PORT}`));
}
