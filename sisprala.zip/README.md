# SISPRALA — Sistem Informasi Sarana Prasarana

Aplikasi peminjaman barang bergaya [pinzup.asia](https://pinzup.asia) — tetapi dengan **data di server (SQLite), login, dan postur keamanan yang sudah diperbaiki** (lihat `audit-pinzup.asia.md`).

## Stack
- **Node.js ≥ 22** + **Express**
- **SQLite** via `better-sqlite3` (file `data/pinzup.db`, dibuat otomatis)
- Template server-side (tanpa framework view) + vanilla JS
- Auth: `node:crypto` scrypt + cookie sesi + CSRF token
- Upload gambar: `multer` (maks 2 MB, hanya png/jpg/webp/gif)

Total dependency runtime: `express`, `better-sqlite3`, `multer`, `qrcode`.

## Menjalankan
```bash
npm install
npm start          # http://localhost:3000
# atau
npm run dev        # auto-reload (node --watch)
```
Login bawaan: user **`admin`**, sandi **`admin123`** (atau nilai env `ADMIN_PASSWORD` kalau diisi sebelum start pertama) — segera ubah di menu **Pengaturan → Keamanan**.

## Test
```bash
npm test           # node:test, 21 test end-to-end
```

## Fitur
- **Landing page** — halaman publik dengan hero, fitur, cara kerja, CTA
- **Dashboard** — statistik, donut chart, alert keterlambatan + total denda, aktivitas terbaru
- **Inventaris Sarana** — barang dengan **stok (jumlah unit)**: tambah/edit/hapus, toggle ready/non-ready, upload & ganti gambar, pencarian. Barang yang **punya riwayat peminjaman tidak bisa dihapus** (riwayatnya akan ikut musnah karena `ON DELETE CASCADE`) — pakai **Non-Ready** untuk menonaktifkannya
- **Inventaris Prasarana** — barang tanpa stok, terpisah dari Sarana (data & form masing-masing)
- **Responsif** — di layar < 800px sidebar berubah jadi menu hamburger (tombol + backdrop)
- **QR per barang** — tiap barang punya QR (SVG) menuju halaman detail `/barang/:id`
- **Peminjaman** — catat pinjam, kembalikan, deteksi terlambat, **denda otomatis**, aturan 1 pinjaman aktif per barang
- **Notifikasi** — log + kirim ke webhook (gateway WhatsApp/email) saat pinjam/kembali/terlambat
- **Riwayat** — log aktivitas + log notifikasi
- **Pengaturan** — nama organisasi, tema, tarif denda, webhook, ubah sandi, export CSV & backup JSON, **restore dari file backup** (mengganti seluruh data)
- **Deploy** — `render.yaml` + `DEPLOY.md`

## Keamanan (hasil perbaikan audit)
| Aspek | Implementasi |
|---|---|
| XSS | Semua output lewat `esc()`; CSP ketat tanpa `unsafe-inline` |
| CSV injection | `src/csv.js` menetralkan sel diawali `= + - @` |
| Auth | scrypt + sesi DB + cookie `HttpOnly`/`SameSite=Lax` |
| CSRF | Token sesi pada semua POST |
| Header | CSP, X-Frame-Options=DENY, nosniff, Referrer-Policy, Permissions-Policy, HSTS |
| SQLi | Semua query *prepared statement* |
| Rate limit | Login dibatasi 5 percobaan/5 menit per IP |
| Upload | Whitelist MIME + batas ukuran |
| Webhook | URL notifikasi divalidasi harus `http(s)://` |

## Struktur
```
server.js            # bootstrap Express + middleware keamanan
src/db.js            # SQLite, migrasi, seed, helper
src/auth.js          # scrypt, sesi, CSRF, middleware
src/render.js        # escaping + layout halaman (SSR)
src/routes.js        # semua route (halaman + aksi + API)
src/csv.js           # export CSV aman
public/css/style.css # UI
public/js/app.js     # clock, chart, filter, konfirmasi, modal edit, menu mobile
test/app.test.js     # 24 test end-to-end
render.yaml          # blueprint deploy Render
DEPLOY.md            # panduan deploy
data/, public/uploads/  # dibuat otomatis
```

## Belum termasuk (bisa ditambah)
Role granular (admin vs petugas), notifikasi email built-in (butuh SMTP), migrasi ke Postgres untuk multi-instance.

Diketahui belum ada dan **sengaja** ditunda:
- Pencarian + paginasi di halaman Peminjaman & Riwayat. `/riwayat` memotong diam-diam ke 200 aktivitas dan 50 notifikasi terakhir.
- Halaman error kustom (404/500) dan handler `SIGTERM`; restart ditangani Passenger.
- Monitor uptime: butuh layanan eksternal (mis. UptimeRobot). Cron DirectAdmin di hosting `sisprala.my.id` tidak dieksekusi, jadi jangan dipakai untuk ini — lihat `DEPLOY.md`.
